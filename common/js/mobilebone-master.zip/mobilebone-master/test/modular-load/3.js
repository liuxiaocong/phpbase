define(function(require, exports, module) {
	exports.init = function(page) {
		page.innerHTML = '<p><input type="button" value="点击我3"></p>';
	};
});